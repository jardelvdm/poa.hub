<?php
/**
 *
 * Funcoes para o tema Epico Junior
 *
 * @package    Epico_Jr
 * @subpackage Functions
 * @version    1.1.0
 * @since      1.0.0
 * @author     Uberfacil <contato@uberfacil.com>
 * @copyright  Copyright (c) 2014, Uberfacil
 * @link       http://uberfacil.com
 * @license    http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 */


/* Adiciona a funcao de configuracao do tema junior */
add_action( 'after_setup_theme', 'epico_junior_setup', 11 );

/* Funcao de configuracao. Inclua suas acoes e filtros aqui dentro */
function epico_junior_setup() {

	/* Carrega arquivos de traducao a partir do tema filho */
	load_child_theme_textdomain( 'epico_junior', get_stylesheet_directory() . '/languages' );

	/* Remove as folhas de estilo originais. */
	remove_action( 'wp_enqueue_scripts', 'epico_register_color_styles', 1 );

	/* Registra estilos personalizados para o frontend. */
	add_action( 'wp_enqueue_scripts', 'epico_junior_register_color_styles', 1 );

	/* Filtros e acoes do EJ personalizadas a partir daqui */

}

/**
 * Registra novamente folhas de estilos para as paletas de cor,
 * reafirmando a folha de estilos do tema pai como dependencia.
 *
 * Como o WordPress renomeia o slug da folha de estilos pai para
 * `parent`, e necesario reajustar as dependencias ao carregar
 * as mesmas folhas de estilos, permitindo que o tema junior as
 * sobrescreva.
 *
 * @since  1.0.0
 * @access public
 * @return void
 */
function epico_junior_register_color_styles() {

	// Estilos de cor 2 a 6
	wp_register_style( 'epico-style-2', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style2.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-3', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style3.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-4', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style4.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-5', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style5.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-6', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style6.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-7', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style7.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-8', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style8.min.css', array( 'parent' ) );
	wp_register_style( 'epico-style-9', trailingslashit( get_template_directory_uri() ) . 'css/color-styles/min/style9.min.css', array( 'parent' ) );

	// Obtendo os valores do customizer para as paletas de cor
	$colorStyle = get_theme_mod( 'epico_color_palettes' );

	// Enfileirando os estilos
	if ( 1 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-2');
	} elseif ( 2 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-3');
	} elseif ( 3 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-4');
	} elseif ( 4 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-5');
	} elseif ( 5 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-6');
	} elseif ( 6 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-7');
	} elseif ( 7 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-8');
	} elseif ( 8 == $colorStyle ) {
		wp_enqueue_style( 'epico-style-9');
	}
}

/* Funcoes personalizadas a partir daqui */


